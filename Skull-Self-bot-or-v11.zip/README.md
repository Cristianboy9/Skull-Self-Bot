## SELFBOT DISCORD CREADO CON PYTHON

Creado por ᴱʳᴿʳᵒᴿ⁴⁰⁴

Server de soporte: [Click aqui](https://discord.gg/MUGnVADSzX)
